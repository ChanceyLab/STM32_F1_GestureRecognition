#ifndef __DUOJI_H_
#define __DUOJI_H_

#include "sys.h"

#endif
#define pwm1 PEout(0)
#define pwm2 PEout(1)
extern void duoji_init(void);
extern void dj_mid(void);
extern void dj_mora(void);
extern void dj_pk(void);
extern void dj_vs(void);
extern void dj_learn(void);
extern void dj_num(void);
extern void dj_num_1(void);
extern void dj_num_2(void);
extern void three(void);
extern void one(void);
extern void two(void);
extern void dj_change(void);
