#ifndef __KEY_H_
#define __KEY_H_

#include "stm32f10x.h"

#endif

void key_init(void);
extern u8 key_scan(void);


